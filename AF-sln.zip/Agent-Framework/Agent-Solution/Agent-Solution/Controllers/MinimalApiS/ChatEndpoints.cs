﻿using Agent_Solution.Application.Interfaces;

namespace Agent_Solution.Controllers.MinimalApiS
{
    /// <summary>
    /// Provides endpoints for chat operations.
    /// </summary>
    internal static class ChatEndpoints
    {
        /// <summary>
        /// Maps the chat endpoints to the web application.
        /// </summary>
        /// <param name="app">The web application to which the endpoints will be mapped.</param>
        public static void MapChatEndpoints(this WebApplication app)
        {
            /// <summary>
            /// Initiates a chat based on the provided order ID.
            /// </summary>
            /// <param name="orderId">The ID of the order for which the chat is to be initiated.</param>
            /// <param name="agentService">The service used to initiate the chat.</param>
            /// <returns>The result of the chat initiation.</returns>
            _ = app.MapGet(
                "/initiatechat/{orderId}",
            async (string orderId, IAgentsOpenAIService agentService) =>
                {
                    var value = await agentService.InitiateChatAsync($"Summarize_The_Content '{orderId}'").ConfigureAwait(false);
                    return Results.Ok(value);
                });
        }
    }
}
