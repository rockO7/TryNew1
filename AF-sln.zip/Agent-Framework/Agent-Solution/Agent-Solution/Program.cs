using Agent_Solution.Application.Interfaces;
using Agent_Solution.Application.Services;
using Agent_Solution.Controllers.MinimalApiS;
using Agent_Solution.Plugins;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

builder.Services.AddScoped<IAgentsOpenAIService, AgentsOpenAIService>();
builder.Services.AddScoped<CricketersPlugin>();
builder.Services.AddScoped<FoundersPlugin>();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapChatEndpoints();

app.MapControllers();

app.Run();
