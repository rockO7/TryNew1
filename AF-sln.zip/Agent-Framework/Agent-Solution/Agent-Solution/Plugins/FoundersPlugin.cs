﻿using Microsoft.SemanticKernel;
using System.ComponentModel;
using System.Text.Json;

namespace Agent_Solution.Plugins
{
    /// <summary>
    /// CricketersPlugin
    /// </summary>
    public class FoundersPlugin
    {
        /// <summary>
        /// Gets the earnest money details asynchronous.
        /// </summary>
        /// <param name="escrowId">The escrow identifier.</param>
        /// <param name="context">The context.</param>
        /// <returns>value</returns>
        [KernelFunction, Description("Get Me Information About Founders.")]
        public async Task<string> GetFoundersDetails(
          [Description("Escrow id")] int escrowId,
          KernelArguments context)
        {
            var orderDocumentsTask = """
                            {
                              "name": "Steven Paul Jobs",
                              "birthDate": "1955-02-24",
                              "deathDate": "2011-10-05",
                              "birthPlace": "San Francisco, California, U.S.",
                              "parents": {
                                "biologicalFather": "Abdulfattah Jandali",
                                "biologicalMother": "Joanne Carole Schieble",
                                "adoptiveFather": "Paul Reinhold Jobs",
                                "adoptiveMother": "Clara Hagopian Jobs"
                              },
                              "education": "Reed College (dropped out)",
                              "career": {
                                "roles": [
                                  "Co-founder of Apple Inc.",
                                  "Chairman and CEO of Apple Inc.",
                                  "CEO of Pixar Animation Studios"
                                ],
                                "keyInnovations": [
                                  "Personal computers (Apple I, Apple II, Macintosh)",
                                  "Animated films (Pixar)",
                                  "Music player (iPod)",
                                  "Mobile phone (iPhone)",
                                  "Tablet computer (iPad)"
                                ]
                              },
                              "personalLife": {
                                "spouse": "Laurene Powell Jobs",
                                "children": [
                                  {"name": "Lisa Brennan-Jobs"},
                                  {"name": "Reed Jobs"},
                                  {"name": "Erin Sienna Jobs"},
                                  {"name": "Eve Jobs"}
                                ],
                                "other": "Known for his demanding personality and perfectionism"
                              },
                              "companies": [
                                "Apple Inc.",
                                "Pixar Animation Studios",
                                "NeXT"
                              ],
                              "awardsAndRecognition": [
                                "National Medal of Technology and Innovation",
                                "Numerous posthumous awards and recognitions"
                              ],
                              "legacy": {
                                "impact": "Revolutionized the personal computer, music, mobile phone, and animated film industries",
                                "influence": "His vision and leadership continue to influence technology and design"
                              },
                              "quotes": [
                                "\"The only way to do great work is to love what you do.\"",
                                "\"Stay hungry. Stay foolish.\"",
                                "\"Your time is limited, so don't waste it living someone else's life.\""
                              ],
                              "other": {
                                "knownFor": "Visionary leadership, design sense, and entrepreneurial spirit",
                                "healthIssues": "Pancreatic neuroendocrine tumor"
                              }
                            }
                            """;
            var orderDocumentsTask1 = """
                    {
                      "name": "William Henry Gates III",
                      "birthDate": "1955-10-28",
                      "birthPlace": "Seattle, Washington, U.S.",
                      "parents": {
                        "father": "William H. Gates Sr.",
                        "mother": "Mary Maxwell Gates"
                      },
                      "education": "Lakeside School, Seattle; Harvard University (dropped out)",
                      "career": {
                        "roles": [
                          "Co-founder of Microsoft Corporation",
                          "Chairman of Microsoft (various periods)",
                          "CEO of Microsoft (various periods)",
                          "Philanthropist"
                        ],
                        "keyAchievements": [
                          "Co-founded Microsoft, the world's largest software company",
                          "Led the development of MS-DOS and Windows operating systems",
                          "Transformed the personal computer industry",
                          "Established the Bill & Melinda Gates Foundation, one of the world's largest private charitable foundations"
                        ]
                      },
                      "personalLife": {
                        "spouse": "Melinda French Gates (divorced)",
                        "children": [
                          {"name": "Jennifer Katharine Gates"},
                          {"name": "Rory John Gates"},
                          {"name": "Phoebe Adele Gates"}
                        ]
                      },
                      "companies": [
                        "Microsoft Corporation",
                        "bgC3 (Bill Gates' private office)"
                      ],
                      "philanthropy": {
                        "foundation": "Bill & Melinda Gates Foundation",
                        "focusAreas": [
                          "Global health",
                          "Poverty reduction",
                          "Education"
                        ],
                        "keyInitiatives": [
                          "Eradication of polio",
                          "Development of vaccines",
                          "Improvement of sanitation",
                          "Support for education and libraries"
                        ]
                      },
                      "awardsAndRecognition": [
                        "Knight Commander of the Order of the British Empire (honorary)",
                        "Presidential Medal of Freedom",
                        "Numerous honorary degrees and awards"
                      ],
                      "netWorth": "One of the wealthiest people in the world (fluctuates)",
                      "books": [
                        "The Road Ahead",
                        "Business @ the Speed of Thought",
                        "How to Avoid a Climate Disaster"
                      ],
                      "other": {
                        "knownFor": "Entrepreneurship, technology leadership, and philanthropy",
                        "interests": "Reading, Bridge, Tennis",
                        "politicalViews": "Generally considered liberal/progressive"
                      }
                    }

                    """;

            var orderDocuments = orderDocumentsTask;
            var orderDocuments1 = orderDocumentsTask1;

            // Serialize the results
            var smartViewInformation = JsonSerializer.Serialize(orderDocuments);
            var smartViewInformation1 = JsonSerializer.Serialize(orderDocuments1);

            // Construct the final content
            var finalContent = $"Data From OrderServiceViewRepository: {smartViewInformation} " +
                               $"Data From OrderDocumentRepository: {smartViewInformation1} ";
            await Task.CompletedTask;
            return finalContent;
        }
    }
}
