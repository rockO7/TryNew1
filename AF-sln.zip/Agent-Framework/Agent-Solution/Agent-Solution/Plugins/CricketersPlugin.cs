﻿using Microsoft.SemanticKernel;
using System.ComponentModel;
using System.Text.Json;

namespace Agent_Solution.Plugins
{
    /// <summary>
    /// CricketersPlugin
    /// </summary>
    public class CricketersPlugin
    {
        /// <summary>
        /// Gets the earnest money details asynchronous.
        /// </summary>
        /// <param name="escrowId">The escrow identifier.</param>
        /// <param name="context">The context.</param>
        /// <returns>value</returns>
        [KernelFunction, Description("Get Me Information About Cricket Players.")]
        public async Task<string> GetCricketersDetails(
          [Description("Escrow id")] int escrowId,
          KernelArguments context)
        {
            var orderDocumentsTask = """
                            {
                              "name": "Virat Kohli",
                              "birthDate": "1988-11-05",
                              "birthPlace": "Delhi, India",
                              "family": {
                                "father": "Premji Kohli (Criminal Lawyer)",
                                "mother": "Saroj Kohli (Housewife)",
                                "siblings": ["Vikash Kohli (Brother)", "Bhavna Kohli (Sister)"]
                              },
                              "education": "Dropped out of school after 11th grade",
                              "cricketCareer": {
                                "battingStyle": "Right-handed batsman",
                                "bowlingStyle": "Right-arm medium",
                                "role": "Top-order batsman",
                                "internationalDebut": {
                                  "odi": "2008-08-18",
                                  "test": "2011-06-20",
                                  "t20i": "2010-06-12"
                                },
                                "captaincy": {
                                  "india": "Captained India in all three formats (Test, ODI, T20I)"
                                },
                                "achievementsAndRecords": [
                                  "One of the greatest batsmen of all time",
                                  "Holds numerous records in ODI and Test cricket, including most centuries in ODI cricket.",
                                  "Fastest batsman to reach many milestones in international cricket.",
                                  "First player to score 20,000 runs in a decade.",
                                  "Most runs in the IPL.",
                                  "10 ICC Awards, the most by any player in international cricket history."
                                ]
                              },
                              "personalLife": {
                                "spouse": "Anushka Sharma (Indian actress)",
                                "children": [
                                    {"name": "Vamika"},
                                    {"name": "Akaay"}
                                  ],
                                "diet": "Vegetarian (since 2018)",
                                "otherInterests": "Co-owns the Indian Super League football club, FC Goa"
                              },
                              "awardsAndRecognition": [
                                "Arjuna Award (2013)",
                                "Padma Shri (2017)",
                                "Major Dhyan Chand Khel Ratna Award (2018)",
                                "ICC Cricketer of the Year (2017, 2018)",
                                "ICC ODI Player of the Year (2012, 2017, 2018, 2023)",
                                "ICC Test Player of the Year (2018)"
                              ],
                              "playingStyle": {
                                "general": "Aggressive and passionate",
                                "strengths": ["Excellent chaser in limited-overs cricket", "Strong leadership skills"]
                              },
                              "other": {
                                "foundation": "Has a foundation named after him that does charitable work",
                                "popularity": "One of the most popular and marketable athletes in the world"
                              }
                            } 
                            """;
            var orderDocumentsTask1 = """
                    {
                      "name": "Mahendra Singh Dhoni",
                      "birthDate": "1981-07-07",
                      "birthPlace": "Ranchi, Jharkhand, India",
                      "family": {
                        "father": "Pan Singh (Pump Operator)",
                        "mother": "Devaki Devi (Homemaker)",
                        "siblings": ["Narendra Singh Dhoni (Brother)", "Jayanti Gupta (Sister)"]
                      },
                      "education": "DAV Jawahar Vidya Mandir, Shyamali, Ranchi",
                      "cricketCareer": {
                        "battingStyle": "Right-handed batsman",
                        "bowlingStyle": "Right-arm medium",
                        "role": "Wicket-keeper batsman",
                        "internationalDebut": {
                          "odi": "2004-12-23",
                          "test": "2005-12-02",
                          "t20i": "2006-06-01"
                        },
                        "captaincy": {
                          "india": "Captained India in all three formats (Test, ODI, T20I)",
                          "ipl": "Captained Chennai Super Kings (CSK)"
                        },
                        "achievementsAndRecords": [
                          "Only captain to win all three ICC trophies (ICC World Twenty20, ICC Cricket World Cup, ICC Champions Trophy)",
                          "Most matches as captain in international cricket",
                          "Most dismissals as a wicketkeeper in ODIs",
                          "Numerous records in ODI cricket",
                          "Known for his finishing abilities and calm demeanor"
                        ]
                      },
                      "personalLife": {
                        "spouse": "Sakshi Dhoni",
                        "children": [
                          {
                            "name": "Ziva Dhoni"
                          }
                        ],
                        "otherInterests": "Motorcycles, Cars, Business ventures"
                      },
                      "awardsAndRecognition": [
                        "Rajiv Gandhi Khel Ratna (now Major Dhyan Chand Khel Ratna Award) (2007)",
                        "Padma Shri (2009)",
                        "Padma Bhushan (2018)",
                        "ICC ODI Player of the Year (2008, 2009)",
                        "ICC Men's T20 World Cup Player of the Tournament (2007)"
                      ],
                      "playingStyle": {
                        "general": "Aggressive batting style, innovative captaincy",
                        "strengths": [
                          "Excellent finisher",
                          "Wicket-keeping skills",
                          "Calm and composed under pressure",
                          "Strategic captaincy"
                        ]
                      },
                      "retirement": {
                        "international": "Retired from international cricket on 15 August 2020",
                        "ipl": "Continues to play in the IPL"
                      },
                      "other": {
                        "nickname": "Captain Cool",
                        "armyRank": "Honorary Lieutenant Colonel in the Territorial Army"
                      }
                    }

                    """;

            var orderDocuments = orderDocumentsTask;
            var orderDocuments1 = orderDocumentsTask1;

            // Serialize the results
            var smartViewInformation = JsonSerializer.Serialize(orderDocuments);
            var smartViewInformation1 = JsonSerializer.Serialize(orderDocuments1);

            // Construct the final content
            var finalContent = $"Data From OrderServiceViewRepository: {smartViewInformation} " +
                               $"Data From OrderDocumentRepository: {smartViewInformation1} ";
            await Task.CompletedTask;
            return finalContent;
        }
    }
}
