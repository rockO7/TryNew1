﻿// <copyright file="AgentsOpenAIService.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

using Agent_Solution.Application.Interfaces;
using Agent_Solution.Plugins;
using AutoGen.Core;
using Fnf.Ai.Agent.Core.Agent;
using Fnf.Ai.Agent.Core.Config;
using Fnf.Ai.Agent.Core.Middleware;
using Microsoft.SemanticKernel;

namespace Agent_Solution.Application.Services
{
    /// <summary>
    /// AgentsOpenAIService
    /// </summary>
    /// <seealso cref="EscrowAgentFrameworkUi.Services.Agents.IAgentsOpenAIService" />
    public class AgentsOpenAIService : IAgentsOpenAIService
    {
        private const string SystemMessageForManager = """
                            ## Role
                            You are a Manager responsible for carefully reading the conversation history and managing task creation. You **must not** respond to the user directly under any circumstances. Instead, follow these strict steps:

                            ### **Step-by-Step Instructions**  

                            1. **Analyze the User's Query**:    
                               - Carefully read the last message from the user.  
                               - Understand what the user is asking for, including any implicit requests or required data.  

                            2. **Break Down the Query into Actionable Tasks**:    
                               - Divide the user's request into smaller, manageable tasks.  
                               - Determine what data needs to be retrieved and what actions need to be performed.  

                            3. **Assign Appropriate Agents to Each Task**:     
                               - **Data Retrieval**: Assign relevant **Data Agents** to retrieve necessary information.  
                               - **Data Processing or Actions**: Assign relevant any one **General Agents** to process data or perform actions based on the user's request.  
                               - **Order Tasks Logically**: Ensure tasks are ordered in a way that makes logical sense for execution.  

                            4. **Prepare the List of Tasks and Assigned Agents**:    
                               - Format the output as a numbered list.  
                               - For each task, specify:  
                                 - **Agent Name** (bold and enclosed with double asterisks, e.g., **SoftproTicor**)  
                                 - **Task Description**: A brief imperative statement describing what the agent should do.  

                            5. **Conclude with the Terminate Agent**:    
                               - The final task should be assigned to the **Terminate** agent.  
                               - This indicates that all tasks are completed.  

                            ### **Important Rules**  

                            - **Last Message Verification**: Only create tasks if the last message is from the user.  
                            - **No Direct Responses**: Do not respond to the user directly.  
                            - **No Self-Performed Tasks**: Do not perform any tasks yourself.  
                            - **Single Role Focus**: Your sole responsibility is to create and assign tasks as per the steps above.
                            - **Pick single General Agent**: Always Pick only one General Agent for processing data retrieved from data agents.

                            ## Available Data Agents
                            These agents must be used with General Agents to complete the task
                            - **SmartViewTicor**: Retrieves SmartView order information from the database using OrderID in JSON format. 
                            - **EarnestMoney**: Retrieves Earnest Money information from the database using escrow id in JSON format.  

                            ## Available General Agents
                             Always pick only one general agent
                            - **Summarize_The_Content**: Summarizes the content.
                            - **Email_Writer**: Drafts emails based on the user question.
                            - **Greetings**: Helps to greet a user.
                            - **ActionAgent**: Handles all other tasks that don't involve summarization, email writing, or greetings.
                            - **Terminate**: All tasks are completed.

                            ### Example 1:
                            Let's say if user greets with Hi, hello, etc
                            User: Hi, there?
                            **Task**: Please greet the user.

                            **Assigned Agents**:
                            1. **Greetings**: Greet the user.
                            2. **Terminate**: All tasks are completed. 

                            ### Example 2:
                            User: Summarize the SmartView Order details for the OrderId 9500062  
                            **Task**: Summarize the SmartView order details.

                            **Assigned Agents**:
                            1. **SmartViewTicor**: Retrieve SmartView orders for 9500062.
                            3. **Summarize_The_Content**: Please summarize the SmartView order information.
                            4. **Terminate**: All tasks are completed. 

                            ### Example 3:
                            User: Draft an email for the Earnest money status for the escrow id 9500062
                            **Task**: Draft an email for the earnest money status.

                            **Assigned Agents**:
                            1. **EarnestMoney**: Retrieve earnest money details for 9500062.
                            3. **Email_Writer**: Draft an emails for the Earnest money status.
                            4. **Terminate**: All tasks are completed. 

                            ### Example 4:
                            User: Draft an email for the Earnest money status for 95000610
                            **Task**: Draft an email for the earnest money status.
                            
                            **Assigned Agents**:
                            1. **EarnestMoney**: Retrieve earnest money details for 95000610.
                            3. **Email_Writer**: Draft an emails for the Earnest money status.
                            4. **Terminate**: All tasks are completed. 

                            Your role is to create tasks based on user input. Never provide a direct response to the user.
                            
                            """;
        private const string SystemMessageForSmartView = """
                            ##Role  
                            - Act as an expert in extracting recent orders information from SmartView.  
                            - Utilize available and appropriate functions and methods registered with you to gather this information.  
                            
                            ##Task  
                            - Identify the necessary SmartView details needed.  
                            - Use available functions and methods to retrieve accurate and relevant SmartView details.  
                            - Provide clear and concise information to the user based on the retrieved customer data.  
                            
                            ##Goal  
                            - The goal is to efficiently and accurately obtain SmartView details using the appropriate methods and functions registered with the expert.
                              The expert should ensure providing clear and useful information to the user.

                            """;
        private const string SystemMessageForEarnestMoney = """
                            ##Role  
                            - Act as an expert in extracting Earnest money amount and its Details from  Database.  
                            - Utilize available and appropriate functions and methods registered with you to gather recent order details.  

                            ##Task 
                            - Use available functions and methods to extract accurate and relevant recent order information.
                            - Get the details from the Database using the provided escrow Id.
                            - Provide Status of Earnest Money from Notes in Database, Amount and Balance for all cases and Pending Amount of cases with Partial Amount received.
                            - Provide clear and concise recent order information to the user based on the extracted data. 
                            - After getting the data inform manager to draft email based on the information and then send that email as response

                            ##Goal  
                            - The goal is to efficiently and accurately extract recent orders information using the appropriate methods and functions registered with the expert. The expert should ensure providing clear and useful recent order details to the user. 
                            """;

        private const string TerminateSystemMessage = """
                            You are an AI to terminate chat. You always reply by saying "The play has been successfully completed. "[TERMINATE]".
                            """;

        private const string AdminSystemMessage = """
                            You are an Admin responsible for coordinating roles in a play. Follow these strict instructions:
                            
                            0. ** Always Assign the Task to Manager First****
                            1. **Start by selecting the Manager and ensure no other agent responds before the Manager has defined the tasks.** This is non-negotiable. The Manager must be the first to act.
                            2. **Choose the next speaker based on the tasks defined by the Manager**, ensuring tasks are carried out in the correct sequence.
                            3. **Once all the defined tasks are completed by the agents, assign the Terminate to complete the play.**
                            
                            ##Example:
                            Step 1: From Manager
                            Step 2: From Agent-2
                            Step 3: From Agent-3
                            Step 4: From Terminate                            
                            """;

        private readonly AzureOpenAIConfig _config;
       

       
        public AgentsOpenAIService()
        {
            // Azure OpenAI init
            _config = new AzureOpenAIConfig("https://oai-access-1.openai.azure.com/", "chatgpt-4o-mini", temperature: 0);

        }

        /// <summary>
        /// Initiates the chat asynchronous.
        /// </summary>
        /// <param name="userMessage">The user message.</param>
        /// <returns>value</returns>
        public async Task<string> InitiateChatAsync(string userMessage)
        {
            var admin = new AssistantAgent(
                name: "Admin",
                description: "You are in a role play game.",
                systemMessage: AdminSystemMessage,
                llmConfig: _config)
                .RegisterPrintMessage();

            IEnumerable<IAgent> agents = [GetManagerAgent(), GentEarnestAgent(), GetSmartViewAgent(), GetTerminatorAgent()];
            var taskManager = new AgentsChatManager(agents, admin, config: _config);

            var reply = await admin.InitiateChatAsync(taskManager, userMessage).ConfigureAwait(false);
            var replayList = reply.ToList();
            return reply?.ElementAtOrDefault(replayList.Count - 2)?.GetContent();
        }

        private MiddlewareAgent<AssistantAgent> GetSmartViewAgent()
        {
            // Plugins
            var smartviewKernelBuilder = Kernel.CreateBuilder();
            var smartviewKernel = smartviewKernelBuilder.Build();
            var smartviewPlugin = smartviewKernel.ImportPluginFromObject(
                new FoundersPlugin(),"FoundersPlugin"
                );
            var smartviewKernelPluginMiddleware = new KernelPluginMiddleware(smartviewKernel, smartviewPlugin);

            return new AssistantAgent(
            name: "SmartViewTicor",
            description: "act as smartview expert",
            systemMessage: SystemMessageForSmartView,
            llmConfig: _config)
            .RegisterMiddleware(smartviewKernelPluginMiddleware)
            .RegisterPrintMessage();
        }

        private MiddlewareAgent<AssistantAgent> GentEarnestAgent()
        {
            // Plugins
            var earnestMoneyKernelBuilder = Kernel.CreateBuilder();
            var earnestMoneyKernel = earnestMoneyKernelBuilder.Build();
            var earnestMoneyPlugin = earnestMoneyKernel.ImportPluginFromObject(
                new CricketersPlugin(), "CricketersPlugin");
            var earnestMoneyKernelPluginMiddleware = new KernelPluginMiddleware(earnestMoneyKernel, earnestMoneyPlugin);

            return new AssistantAgent(
            name: "EarnestMoney",
            description: "act as a earnest money expert.",
            systemMessage: SystemMessageForEarnestMoney,
            llmConfig: _config)
            .RegisterMiddleware(earnestMoneyKernelPluginMiddleware)
            .RegisterPrintMessage();
        }

        private MiddlewareAgent<AssistantAgent> GetTerminatorAgent()
        {
            var admin = new AssistantAgent(
                name: "Terminate",
                description: "Terminate the chat by saying [TERMINATE].",
                systemMessage: TerminateSystemMessage,
                llmConfig: _config)
                .RegisterPrintMessage();

            return admin;
        }

        private MiddlewareAgent<AssistantAgent> GetManagerAgent()
        {
            var managerAgent = new AssistantAgent(
                name: "Manager",
                description: "Act as a manager",
                systemMessage: SystemMessageForManager,
                llmConfig: _config).RegisterPrintMessage();

            return managerAgent;
        }
    }
}