﻿namespace Agent_Solution.Application.Interfaces
{
    public interface IAgentsOpenAIService
    {
        Task<string> InitiateChatAsync(string userMessage);
    }
}
