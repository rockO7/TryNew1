﻿// <copyright file="TaskAssignmentOrchestrator.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using System.Text.Json.Serialization;
using AutoGen.Core;
using Json.Schema.Generation;

namespace Fnf.Ai.Agent.Core.Orchestrator;

/// <summary>
/// TaskAssignment Orchestrator.
/// </summary>
/// <seealso cref="AutoGen.Core.IOrchestrator" />
public class TaskAssignmentOrchestrator : IOrchestrator
{
    private readonly IAgent _admin;
    private readonly Graph? _workflow;

    /// <summary>
    /// Initializes a new instance of the <see cref="TaskAssignmentOrchestrator"/> class.
    /// </summary>
    /// <param name="admin">The admin.</param>
    /// <param name="workflow">The workflow.</param>
    public TaskAssignmentOrchestrator(IAgent admin, Graph? workflow = null)
    {
        this._admin = admin;
        this._workflow = workflow;
    }

    /// <summary>
    /// Return the next agent as the next speaker. return null if no agent is selected.
    /// </summary>
    /// <param name="context">orchestration context, such as candidate agents and chat history.</param>
    /// <param name="cancellationToken">cancellation token</param>
    /// <returns>The Agent.</returns>
    public async Task<IAgent?> GetNextSpeakerAsync(
        OrchestrationContext context,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(context);
        var candidates = context.Candidates.ToList();

        if (candidates.Count == 0)
        {
            return null;
        }

        if (candidates.Count == 1)
        {
            return candidates[0];
        }

        // if there's a workflow
        // and the next available agent from the workflow is in the group chat
        // then return the next agent from the workflow
        if (this._workflow != null)
        {
            var lastMessage = context.ChatHistory.LastOrDefault();
            if (lastMessage == null)
            {
                return null;
            }

            var currentSpeaker = candidates.First(candidates => candidates.Name == lastMessage.From);
            var nextAgents = await this._workflow.TransitToNextAvailableAgentsAsync(currentSpeaker, context.ChatHistory, cancellationToken)
                .ConfigureAwait(false);
            nextAgents = nextAgents.Where(nextAgent => candidates.Exists(candidate => candidate.Name == nextAgent.Name));
            candidates = nextAgents.ToList();
            if (candidates.Count == 0)
            {
                return null;
            }

            if (candidates is { Count: 1 })
            {
                return candidates[0];
            }
        }

        // In this case, since there are more than one available agents from the workflow for the next speaker
        // the admin will be invoked to decide the next speaker
        var agentNames = candidates.Select(candidate => candidate.Name);
        var content = $"""
                                You are in a role play game. Carefully read the conversation history and carry on the conversation.
                                The available roles are:
                                {string.Join(",", agentNames)}

                                Each message will start with 'From name:', e.g:
                                From {agentNames.First()}:
                                //your message//.
                                """;
        var rolePlayMessage = new TextMessage(
            Role.User,
            content: content,
            from: "Admin");

        // structured output
        ////var schemaBuilder = new JsonSchemaBuilder().FromType<AgentJson>();
        ////var schema = schemaBuilder.Build();

        var chatHistoryWithName = ProcessConversationsForRolePlay(context.ChatHistory);
        var messages = new IMessage[] { rolePlayMessage }.Concat(chatHistoryWithName);

        var response = await this._admin.GenerateReplyAsync(
            messages: messages,
            options: new GenerateReplyOptions
            {
                Temperature = 0,
                MaxToken = 128,
                StopSequence = [":"],
                Functions = null,
                ////OutputSchema = schema,
            },
            cancellationToken: cancellationToken)
            .ConfigureAwait(false);

        var name = response.GetContent() ?? null;

        // remove From
        name = name![5..];
        var candidate = candidates.Find(x => x.Name!.ToLower() == name.ToLower());

        return candidate;
    }

    private static IEnumerable<IMessage> ProcessConversationsForRolePlay(IEnumerable<IMessage> messages)
    {
        return messages.Select((x, i) =>
        {
            var msg = @$"From {x.From}:
                            {x.GetContent()}
                            <eof_msg>
                            round # {i}";

            return new TextMessage(Role.User, content: msg);
        });
    }

    /// <summary>
    /// Agent Json for structured output fro open AI
    /// </summary>
    [Title("Agent")]
    internal class AgentJson
    {
        /// <summary>
        /// Gets or sets the name of the agent.
        /// </summary>
        /// <value>
        /// The name of the agent.
        /// </value>
        [JsonPropertyName("AgentName")]
        [Description("Name of the Agent")]
        [Required]
        public required string AgentName { get; set; }
    }
}
