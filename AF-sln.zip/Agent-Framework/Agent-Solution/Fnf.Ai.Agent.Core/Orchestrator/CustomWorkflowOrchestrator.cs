﻿// <copyright file="CustomWorkflowOrchestrator.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using AutoGen.Core;

namespace Fnf.Ai.Agent.Core.Orchestrator;

/// <summary>
/// 
/// </summary>
/// <seealso cref="AutoGen.Core.IOrchestrator" />
public class CustomWorkflowOrchestrator : IOrchestrator
{
    private readonly Graph workflow;

    /// <summary>
    /// Initializes a new instance of the <see cref="CustomWorkflowOrchestrator"/> class.
    /// </summary>
    /// <param name="workflow">The workflow.</param>
    public CustomWorkflowOrchestrator(Graph workflow)
    {
        this.workflow = workflow;
    }

    /// <summary>
    /// Return the next agent as the next speaker. return null if no agent is selected.
    /// </summary>
    /// <param name="context">orchestration context, such as candidate agents and chat history.</param>
    /// <param name="cancellationToken">cancellation token</param>
    /// <returns>Returns Agents</returns>
    /// <exception cref="System.ArgumentException">There are more than one available agents from the workflow for the next speaker.</exception>
    public async Task<IAgent?> GetNextSpeakerAsync(
        OrchestrationContext context,
        CancellationToken cancellationToken = default)
    {
        var lastMessage = context.ChatHistory.LastOrDefault();
        if (lastMessage == null)
        {
            return null;
        }

        var candidates = context.Candidates.ToList();
        var currentSpeaker = candidates.FirstOrDefault(candidates => candidates.Name == lastMessage.From);

        if (currentSpeaker == null)
        {
            return null;
        }
        var nextAgents = await this.workflow.TransitToNextAvailableAgentsAsync(currentSpeaker, context.ChatHistory, cancellationToken);
        nextAgents = nextAgents.Where(nextAgent => candidates.Any(candidate => candidate.Name == nextAgent.Name));
        candidates = nextAgents.ToList();
        if (!candidates.Any())
        {
            return null;
        }

        if (candidates is { Count: 1 })
        {
            return candidates.First();
        }
        else
        {
            throw new ArgumentException("There are more than one available agents from the workflow for the next speaker.");
        }
    }
}

