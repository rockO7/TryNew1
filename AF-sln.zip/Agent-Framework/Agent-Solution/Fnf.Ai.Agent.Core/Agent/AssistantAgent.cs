﻿// <copyright file="AssistantAgent.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using AutoGen.Core;
using Fnf.Ai.Agent.Core.Config;
using Fnf.Ai.Agent.Core.Extension;
using Fnf.Ai.Agent.Core.Middleware;
using Microsoft.SemanticKernel;
using OpenAI.Chat;

namespace Fnf.Ai.Agent.Core.Agent;

/// <summary>
/// Assistant Agent
/// </summary>
/// <seealso cref="AutoGen.Core.IAgent" />
public class AssistantAgent : IAgent
{
    private readonly IAgent? _innerAgent;
    private readonly string? _defaultReply;
    private readonly IDictionary<string, Func<string, Task<string>>>? _functionMap;
    private readonly string _systemMessage;
    private readonly IEnumerable<KernelFunction>? _functions;

    /// <summary>
    /// Initializes a new instance of the <see cref="AssistantAgent"/> class.
    /// </summary>
    /// <param name="name">The name.</param>
    /// <param name="description">The Agent description or back story.</param>
    /// <param name="systemMessage">The system message.</param>
    /// <param name="innerAgent">The inner agent.</param>
    /// <param name="defaultAutoReply">The default automatic reply.</param>
    /// <param name="functions">The functions.</param>
    /// <param name="functionMap">The function map.</param>
    public AssistantAgent(
        string name,
        string description,
        string systemMessage = "You are a helpful AI assistant",
        IAgent? innerAgent = null,
        string? defaultAutoReply = null,
        IEnumerable<KernelFunction>? functions = null,
        IDictionary<string, Func<string, Task<string>>>? functionMap = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        ArgumentException.ThrowIfNullOrWhiteSpace(description);
        this.Name = name;
        this.Description = description;
        this._defaultReply = defaultAutoReply;
        this._functions = functions;
        this._functionMap = functionMap;
        this._innerAgent = innerAgent;
        this._systemMessage = systemMessage;
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="AssistantAgent"/> class.
    /// </summary>
    /// <param name="name">The name.</param>
    /// <param name="description">The Agent description or back story.</param>
    /// <param name="systemMessage">The system message.</param>
    /// <param name="llmConfig">The LLM configuration.</param>
    /// <param name="functions">The functions.</param>
    /// <param name="functionMap">The function map.</param>
    /// <param name="defaultReply">The default reply.</param>
    public AssistantAgent(
        string name,
        string description,
        string systemMessage = "You are a helpful AI assistant",
        ILLMConfig? llmConfig = null,
        IEnumerable<KernelFunction>? functions = null,
        IDictionary<string, Func<string, Task<string>>>? functionMap = null,
        string? defaultReply = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        ArgumentException.ThrowIfNullOrWhiteSpace(description);
        this.Name = name;
        this.Description = description;
        this._defaultReply = defaultReply;
        this._functions = functions;
        this._functionMap = functionMap;
        this._systemMessage = systemMessage;
        this._innerAgent = llmConfig != null ? this.CreateInnerAgentFromConfigList(llmConfig) : null;
    }

    /// <summary>
    /// Gets the name.
    /// </summary>
    /// <value>
    /// The name.
    /// </value>
    public string Name { get; }

    /// <summary>
    /// Gets the description.
    /// </summary>
    /// <value>
    /// The description.
    /// </value>
    public string Description { get; }

    /// <summary>
    /// Gets the is termination.
    /// </summary>
    /// <value>
    /// The is termination.
    /// </value>
    public Func<IEnumerable<IMessage>, CancellationToken, Task<bool>>? IsTermination { get; }

    /// <summary>
    /// Generates the reply asynchronous.
    /// </summary>
    /// <param name="messages">The messages.</param>
    /// <param name="options">The override options.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>The IMessage.</returns>
    public async Task<IMessage> GenerateReplyAsync(
        IEnumerable<IMessage> messages,
        GenerateReplyOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        // if there's no system message, add system message to the first of chat history
        if (!messages.Any(m => m.IsSystemMessage()))
        {
            var systemMessage = new TextMessage(Role.System, this._systemMessage, from: this.Name);
            messages = new[] { systemMessage }.Concat(messages);
        }

        // process order: function_call -> human_input -> inner_agent -> default_reply -> self_execute
        // first in, last out

        // process default reply
        MiddlewareAgent agent = this._innerAgent != null
            ? this._innerAgent.RegisterMiddleware(async (msgs, option, agent, ct) =>
            {
                var updatedMessages = msgs.Select(m =>
                {
                    if (m.From == this.Name)
                    {
                        m.From = this._innerAgent.Name;
                        return m;
                    }
                    else
                    {
                        return m;
                    }
                });

                return await agent.GenerateReplyAsync(updatedMessages, option, ct).ConfigureAwait(false);
            })
            : new MiddlewareAgent<DefaultReplyAgent>(new DefaultReplyAgent(this.Name!, this._defaultReply ?? "Default reply is not set. Please pass a default reply to assistant agent"));

        // process function call
        var functionContracts = this._functions?.Select(k => k.Metadata.ToFunctionContract());
        var functionCallMiddleware = new FunctionCallMiddleware(functions: functionContracts, functionMap: this._functionMap);
        agent.Use(functionCallMiddleware);

        return await agent.GenerateReplyAsync(messages, options, cancellationToken).ConfigureAwait(false);
    }

    /// <summary>
    /// Creates the inner agent from configuration list.
    /// </summary>
    /// <param name="llmConfig">The LLM configuration.</param>
    /// <returns>The Agent.</returns>
    private IAgent? CreateInnerAgentFromConfigList(ILLMConfig llmConfig)
    {
        var azureConfig = (AzureOpenAIConfig)llmConfig;
        var openAIClient = azureConfig.CreateChatClient();
        IAgent nextAgent = new AzureOpenAIChatAgent(
        openAIClient, this.Name, this._systemMessage, azureConfig.Temperature, azureConfig.MaxTokens, azureConfig.Seed, null, this._functions)
            .RegisterMessageConnector();

        return nextAgent;
    }
}
