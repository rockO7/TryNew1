﻿// <copyright file="AzureOpenAIChatAgent.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using System.Runtime.CompilerServices;
using AutoGen.Core;
using Fnf.Ai.Agent.Core.Extension;
using Json.Schema;
using Microsoft.SemanticKernel;
using OpenAI.Chat;

namespace Fnf.Ai.Agent.Core.Agent;

/// <summary>
/// AzureOpenAI client agent. This agent is a thin wrapper around <see cref="AzureOpenAIChatAgent"/> to provide a simple interface for chat completions.
/// <para><see cref="AzureOpenAIChatAgent" /> supports the following message types:</para>
/// <list type="bullet">
/// <item>
/// <see cref="MessageEnvelope{T}"/> where T is <see cref="ChatMessage"/>: chat message.
/// </item>
/// </list>
/// <para><see cref="AzureOpenAIChatAgent" /> returns the following message types:</para>
/// <list type="bullet">
/// <item>
/// <see cref="MessageEnvelope{T}"/> where T is <see cref="ChatCompletion"/>: chat response message.
/// <see cref="MessageEnvelope{T}"/> where T is <see cref="StreamingChatCompletionUpdate"/>: streaming chat completions update.
/// </item>
/// </list>
/// </summary>
public class AzureOpenAIChatAgent : IStreamingAgent
{
    private readonly ChatClient _chatClient;

    /// <summary>
    /// Initializes a new instance of the <see cref="AzureOpenAIChatAgent"/> class.
    /// </summary>
    /// <param name="chatClient">open ai client</param>
    /// <param name="name">agent name</param>
    /// <param name="systemMessage">system message</param>
    /// <param name="temperature">temperature</param>
    /// <param name="maxTokens">max tokens to generated</param>
    /// <param name="responseFormat">response format, set it to <see cref="ChatResponseFormat.JsonObject"/> to enable json mode.</param>
    /// <param name="seed">seed to use, set it to enable deterministic output</param>
    /// <param name="functions">functions</param>
    public AzureOpenAIChatAgent(
        ChatClient chatClient,
        string name,
        string systemMessage = "You are a helpful AI assistant",
        float temperature = 0.7f,
        int maxTokens = 1024,
        int? seed = null,
        ChatResponseFormat? responseFormat = null,
        IEnumerable<KernelFunction>? functions = null)
        : this(
            chatClient: chatClient,
            name: name,
            options: CreateChatCompletionOptions(temperature, maxTokens, seed, responseFormat, functions),
            systemMessage: systemMessage)
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="AzureOpenAIChatAgent"/> class.
    /// </summary>
    /// <param name="chatClient">open ai chat client</param>
    /// <param name="name">agent name</param>
    /// <param name="systemMessage">system message</param>
    /// <param name="options">chat completion option. The option can't contain messages</param>
    public AzureOpenAIChatAgent(
        ChatClient chatClient,
        string name,
        ChatCompletionOptions options,
        string systemMessage = "You are a helpful AI assistant")
    {
        this._chatClient = chatClient;
        this.Options = options;
        this.Name = name;
        this.SystemMessage = systemMessage;
    }

    /// <summary>
    /// Gets the name.
    /// </summary>
    /// <value>
    /// The name.
    /// </value>
    public string Name { get; }

    /// <summary>
    /// Gets the system message.
    /// </summary>
    /// <value>
    /// The system message.
    /// </value>
    public string SystemMessage { get; }

    /// <summary>
    /// Gets the options.
    /// </summary>
    /// <value>
    /// The options.
    /// </value>
    public ChatCompletionOptions Options { get; }

    /// <summary>
    /// Generate reply
    /// </summary>
    /// <param name="messages">conversation history</param>
    /// <param name="options">completion option. If provided, it should override existing option if there's any</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>The IMessage.</returns>
    public async Task<IMessage> GenerateReplyAsync(
        IEnumerable<IMessage> messages,
        GenerateReplyOptions? options = null,
        CancellationToken cancellationToken = default)
    {
        var chatHistory = this.CreateChatMessages(messages);
        var settings = this.CreateChatCompletionsOptions(options);
        var reply = await this._chatClient.CompleteChatAsync(chatHistory, settings, cancellationToken)
            .ConfigureAwait(false);
        return new MessageEnvelope<ChatCompletion>(reply.Value, from: this.Name);
    }

    /// <summary>
    /// Generates the streaming reply asynchronous.
    /// </summary>
    /// <param name="messages">The messages.</param>
    /// <param name="options">The options.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>The IMessage.</returns>
    public async IAsyncEnumerable<IMessage> GenerateStreamingReplyAsync(
        IEnumerable<IMessage> messages,
        GenerateReplyOptions? options = null,
        [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        var chatHistory = this.CreateChatMessages(messages);
        var settings = this.CreateChatCompletionsOptions(options);
        var response = this._chatClient.CompleteChatStreamingAsync(chatHistory, settings, cancellationToken);
        await foreach (var update in response.WithCancellation(cancellationToken))
        {
            if (update.ContentUpdate.Count > 1)
            {
                throw new InvalidOperationException("Only one choice is supported in streaming response");
            }

            yield return new MessageEnvelope<StreamingChatCompletionUpdate>(update, from: this.Name);
        }
    }

    private static ChatCompletionOptions CreateChatCompletionOptions(
        float temperature = 0.7f,
        int maxTokens = 1024,
        int? seed = null,
        ChatResponseFormat? responseFormat = null,
        IEnumerable<KernelFunction>? functions = null)
    {
#pragma warning disable OPENAI001 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
        var options = new ChatCompletionOptions
        {
            Temperature = temperature,
            Seed = seed,
            ResponseFormat = responseFormat,
            MaxOutputTokenCount = maxTokens,
        };
#pragma warning restore OPENAI001 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.

        var functionContracts = functions?.Select(k => k.Metadata.ToFunctionContract());
        if (functionContracts is not null)
        {
            foreach (var f in functionContracts)
            {
                options.Tools.Add(f.ToChatTool());
            }
        }

        return options;
    }

    private IEnumerable<ChatMessage> CreateChatMessages(IEnumerable<IMessage> messages)
    {
        var oaiMessages = messages.Select(m => m switch
        {
            IMessage<ChatMessage> chatMessage => chatMessage.Content,
            _ => throw new ArgumentException("Invalid message type")
        });

        // add system message if there's no system message in messages
        if (!oaiMessages.Any(m => m is SystemChatMessage) && this.SystemMessage is not null)
        {
            oaiMessages = new[] { new SystemChatMessage(this.SystemMessage) }.Concat(oaiMessages);
        }

        return oaiMessages;
    }

    /// <summary>
    /// Creates the chat completions options.
    /// </summary>
    /// <param name="options">The options.</param>
    /// <returns>The ChatCompletionOptions.</returns>
    private ChatCompletionOptions CreateChatCompletionsOptions(GenerateReplyOptions? options)
    {
#pragma warning disable OPENAI001 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.
        var option = new ChatCompletionOptions()
        {
            Seed = this.Options.Seed,
            Temperature = options?.Temperature ?? this.Options.Temperature,
            ////MaxOutputTokenCount = options?.MaxToken ?? this.Options.MaxOutputTokenCount,
            ResponseFormat = this.Options.ResponseFormat,
            FrequencyPenalty = this.Options.FrequencyPenalty,
            IncludeLogProbabilities = this.Options.IncludeLogProbabilities,
            AllowParallelToolCalls = this.Options.AllowParallelToolCalls,
            PresencePenalty = this.Options.PresencePenalty,
            ToolChoice = this.Options.ToolChoice,
            TopLogProbabilityCount = this.Options.TopLogProbabilityCount,
            TopP = this.Options.TopP,
            EndUserId = this.Options.EndUserId,
        };
#pragma warning restore OPENAI001 // Type is for evaluation purposes only and is subject to change or removal in future updates. Suppress this diagnostic to proceed.

        // add tools from this.options to option
        foreach (var tool in this.Options.Tools)
        {
            option.Tools.Add(tool);
        }

        // add stop sequences from this.options to option
        foreach (var seq in this.Options.StopSequences)
        {
            option.StopSequences.Add(seq);
        }

        var openAIFunctionDefinitions = options?.Functions?.Select(f => f.ToChatTool()).ToList();
        if (openAIFunctionDefinitions is { Count: > 0 })
        {
            foreach (var f in openAIFunctionDefinitions)
            {
                option.Tools.Add(f);
            }
        }

        if (options?.StopSequence is var sequence && sequence is { Length: > 0 })
        {
            foreach (var seq in sequence)
            {
                option.StopSequences.Add(seq);
            }
        }

        if (options?.OutputSchema is not null)
        {
            option.ResponseFormat = ChatResponseFormat.CreateJsonSchemaFormat(
                jsonSchemaFormatName: options.OutputSchema.GetTitle() ?? throw new ArgumentException("Output schema must have a title"),
                jsonSchema: BinaryData.FromObjectAsJson(options.OutputSchema),
                jsonSchemaFormatDescription: options.OutputSchema.GetDescription());
        }

        return option;
    }
}
