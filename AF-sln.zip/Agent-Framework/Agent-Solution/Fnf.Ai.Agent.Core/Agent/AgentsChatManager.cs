﻿// <copyright file="AgentsChatManager.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using AutoGen.Core;
using Fnf.Ai.Agent.Core.Config;
using Fnf.Ai.Agent.Core.Extension;
using Fnf.Ai.Agent.Core.GroupChat;
using OpenAI.Chat;

namespace Fnf.Ai.Agent.Core.Agent;

/// <summary>
/// TaskManager Agent.
/// </summary>
/// <seealso cref="AutoGen.Core.GroupChatManager" />
public class AgentsChatManager : GroupChatManager
{
    private const string GreetingSystemMessage = """
                            ##Role  
                            - Act as an expert in Sales.  
                            - Clearly state that you are available to assist with a variety of Sales tasks.  
                            - Provide a brief, warm greeting that conveys readiness to assist.  

                            ##Task  
                            - Greet the user warmly.  
                            - Clearly indicate your availability to assist with various Sales-related inquiries.  
                            - Invite the user to start interacting and asking questions related to Sales.  

                            ##Goal  
                            - The goal is to establish a welcoming and professional tone that encourages the user to seek assistance with their Sales-related needs. The expert should make it clear that they are ready and able to help with a wide range of tasks, fostering an environment of support and collaboration.  

                            ##Example Prompt  
                            Hello! I'm here to help you with all your Sales-related questions and tasks. How can I assist you today? Feel free to ask me anything related to Sales
                            """;

    private const string SummarizeSystemMessage = """
                            ## Role  
                            - Act as an expert in summarization.

                            ## Task  
                            - Review and analyze the given text.
                            - Identify key points, main ideas, and essential information.
                            - Condense the information into a concise and coherent summary.
                            - Ensure the summary retains the original meaning and context of the text.

                            ## Goal  
                            - To produce a clear, accurate, and comprehensive summary of the provided information.
                            - The summary should be significantly shorter than the original text while still conveying the core message.
                            - The summarization should be useful for readers who need to quickly understand the main points without reading the entire text.

                            ## Instructions:  
                            - Focus solely on summarizing the provided text.
                            - Read the text thoroughly to ensure complete understanding.
                            - Highlight or note down the most important points and ideas.
                            - Rewrite the highlighted information in your own words, forming a concise summary.
                            - Review the summary to ensure it accurately reflects the original text’s key points and context.

                            **Remember:** Only perform summarization. Do not carry out additional tasks like drafting emails or generating other types of content.
                             
                            """;

    private const string EmailWriterSystemMessage = """
                            ## Role  
                            - Act as an expert in email composition.

                            ## Task  
                            - Understand the user's request and the context in which the email is to be written.
                            - Identify the purpose and key points that need to be conveyed in the email.
                            - Structure the email with a clear and professional format, including a subject line, greeting, body, and closing.
                            - Ensure the email is concise, coherent, and tailored to the intended recipient.

                            ## Goal  
                            - To craft a well-written, professional email that effectively communicates the user's intended message.
                            - The email should be engaging, clear, and free of grammatical errors.
                            - The tone and style of the email should be appropriate for the context and recipient.

                            ## Instructions:  
                            - Focus solely on drafting the email.
                            - Begin by gathering all necessary information from the user about the email's purpose and content.
                            - Identify the key points and main message that need to be included in the email.
                            - Write a clear and concise subject line that accurately reflects the email's content.
                            - Compose a professional greeting that addresses the recipient appropriately.
                            - Write the body of the email, ensuring it is structured logically and flows smoothly from one point to the next.
                            - Conclude the email with a courteous closing and include any necessary contact information or next steps.
                            - Review and edit the email to ensure it is free of errors and effectively communicates the intended message.

                            **Remember:** Only perform email drafting. Do not carry out additional tasks like summarization or generating other types of content.
                            """;

    private const string OtherAgentSystemMessage = """
                                You are an expert information assistant.  

                                **Your Role:**  
                                - Provide responses strictly based on the data provided.  

                                **Instructions:**  
                                - Carefully analyze the data provided.  
                                - Extract relevant and accurate information from the given data.  
                                - Formulate clear, concise, and informative responses based on the extracted data.  
                                - If the data is not sufficient to answer a query, politely inform the user.  

                                **Goal:**  
                                - Assist users by providing accurate and helpful information derived from the provided data.  
                                - Ensure that every response is fully aligned with the available data, maintaining high standards of reliability and relevance.  

                                **Remember:**
                                - Respond only to the user's question.  
                                - Do not include any extra information beyond what is requested.  
                                
                                """;

    /// <summary>
    /// Initializes a new instance of the <see cref="AgentsChatManager"/> class.
    /// </summary>
    /// <param name="members">The members.</param>
    /// <param name="adminToManage">The admin to manage.</param>
    /// <param name="initializeMessages">The initialize messages.</param>
    /// <param name="workflow">The workflow.</param>
    /// <param name="config">The configuration.</param>
    /// <param name="streamingMiddleware">The SignalR instance.</param>
    public AgentsChatManager(
        IEnumerable<IAgent> members,
        IAgent? adminToManage = null,
        IEnumerable<IMessage>? initializeMessages = null,
        Graph? workflow = null,
        ILLMConfig? config = null,
        IStreamingMiddleware? streamingMiddleware = null)
        : base(CreateTaskDispatcher(members.Concat(AddDefaultAgents(config, streamingMiddleware)), adminToManage, initializeMessages, workflow))
    {
    }

    private static IEnumerable<IAgent> AddDefaultAgents(ILLMConfig? config, IStreamingMiddleware? streamingMiddleware = null)
    {
        if (config is not null)
        {
            var greetings = new AzureOpenAIChatAgent(
                CreateChatClientFromConfigList(config),
                name: "Greetings",
                systemMessage: GreetingSystemMessage)
                .RegisterMessageConnector()
                .RegisterSignalRMessage(streamingMiddleware);

            var summarizer = new AzureOpenAIChatAgent(
                CreateChatClientFromConfigList(config),
                name: "Summarize_The_Content",
                systemMessage: SummarizeSystemMessage)
                .RegisterMessageConnector()
                .RegisterSignalRMessage(streamingMiddleware);

            var emailWriter = new AzureOpenAIChatAgent(
                CreateChatClientFromConfigList(config),
                name: "Email_Writer",
                systemMessage: EmailWriterSystemMessage)
                .RegisterMessageConnector()
                .RegisterSignalRMessage(streamingMiddleware);

            var otherAgent = new AzureOpenAIChatAgent(
                CreateChatClientFromConfigList(config),
                name: "OtherAgent",
                systemMessage: OtherAgentSystemMessage)
                .RegisterMessageConnector()
                .RegisterSignalRMessage(streamingMiddleware);

            return [greetings, summarizer, emailWriter, otherAgent];
        }

        return [];
    }

    /// <summary>
    /// Creates the task dispatcher.
    /// </summary>
    /// <param name="members">The members.</param>
    /// <param name="adminToManage">The admin to manage.</param>
    /// <param name="initializeMessages">The initialize messages.</param>
    /// <param name="workflow">The workflow.</param>
    /// <returns>The TaskAssignment.</returns>
    private static TaskAssignment CreateTaskDispatcher(
        IEnumerable<IAgent> members,
        IAgent? adminToManage = null,
        IEnumerable<IMessage>? initializeMessages = null,
        Graph? workflow = null)
    {
        return new TaskAssignment(members, adminToManage, initializeMessages, workflow);
    }

    /// <summary>
    /// Creates the inner agent from configuration list.
    /// </summary>
    /// <param name="llmConfig">The LLM configuration.</param>
    /// <returns>The Agent.</returns>
    private static ChatClient CreateChatClientFromConfigList(ILLMConfig llmConfig)
    {
        var azureConfig = (AzureOpenAIConfig)llmConfig;
        var openAIClient = azureConfig.CreateChatClient();

        return openAIClient;
    }
}
