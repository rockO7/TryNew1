﻿using AutoGen.Core;
using System.Runtime.CompilerServices;

namespace Fnf.Ai.Agent.Core.Middleware;

public class SignalRMessageMiddleware : IStreamingMiddleware
{
    private readonly HttpClient _httpClient;

    string testing = string.Empty;

    public SignalRMessageMiddleware(HttpClient httpClient)
    {
        this._httpClient = httpClient;
    }

    public string? Name => nameof(SignalRMessageMiddleware);

    public async Task<IMessage> InvokeAsync(MiddlewareContext context, IAgent agent, CancellationToken cancellationToken = default)
    {
        testing = "testing";
        if (agent is IStreamingAgent streamingAgent)
        {
            IMessage? recentUpdate = null;
            await foreach (var message in this.InvokeAsync(context, streamingAgent, cancellationToken))
            {
                if (message is IMessage imessage)
                {
                    recentUpdate = imessage;
                }
            }
            //Console.WriteLine();
            ////if (recentUpdate is not null && recentUpdate is not TextMessage)
            ////{
            ////    Console.WriteLine(recentUpdate.FormatMessage());
            ////}

            return recentUpdate ?? throw new InvalidOperationException("The message is not a valid message");
        }
        else
        {
            var reply = await agent.GenerateReplyAsync(context.Messages, context.Options, cancellationToken);

            var formattedMessages = reply.FormatMessage();

            //Console.WriteLine(formattedMessages);

            return reply;
        }
    }

    public async IAsyncEnumerable<IMessage> InvokeAsync(MiddlewareContext context, IStreamingAgent agent, [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        IMessage? recentUpdate = null;
        await foreach (var message in agent.GenerateStreamingReplyAsync(context.Messages, context.Options, cancellationToken))
        {
            if (message is TextMessageUpdate textMessageUpdate)
            {
                recentUpdate = new TextMessage(textMessageUpdate);
                Console.Write(recentUpdate.GetContent());

                yield return message;
            }
            else if (message is ToolCallMessageUpdate toolCallUpdate)
            {
                if (recentUpdate is null)
                {
                    recentUpdate = new ToolCallMessage(toolCallUpdate);

                    yield return message;
                }
                else if (recentUpdate is ToolCallMessage recentToolCallMessage)
                {
                    recentToolCallMessage.Update(toolCallUpdate);

                    yield return message;
                }
                else
                {
                    throw new InvalidOperationException("The recent update is not a ToolCallMessage");
                }
            }
            else if (message is IMessage imessage)
            {
                recentUpdate = imessage;

                yield return imessage;
            }
            else
            {
                throw new InvalidOperationException("The message is not a valid message");
            }
        }

        // add streaming stop message

        //Console.WriteLine();
        if (recentUpdate is not null && recentUpdate is not TextMessage)
        {
            //Console.WriteLine(recentUpdate.FormatMessage());
        }

        yield return recentUpdate ?? throw new InvalidOperationException("The message is not a valid message");
    }
}
