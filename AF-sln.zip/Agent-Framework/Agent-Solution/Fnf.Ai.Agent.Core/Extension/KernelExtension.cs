﻿// <copyright file="KernelExtension.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using AutoGen.Core;
using Microsoft.SemanticKernel;

namespace Fnf.Ai.Agent.Core.Extension;

/// <summary>
/// Kernel Extension.
/// </summary>
public static class KernelExtension
{
    /// <summary>
    /// Convert a <see cref="KernelFunctionMetadata"/> to a <see cref="FunctionContract"/>
    /// </summary>
    /// <param name="metadata">kernel function metadata</param>
    public static FunctionContract ToFunctionContract(this KernelFunctionMetadata metadata)
    {
        return new FunctionContract()
        {
            Name = metadata.Name,
            Description = metadata.Description,
            Parameters = metadata.Parameters.Select(p => p.ToFunctionParameterContract()).ToList(),
            ReturnType = metadata.ReturnParameter.ParameterType,
            ReturnDescription = metadata.ReturnParameter.Description,
            ClassName = metadata.PluginName,
        };
    }

    /// <summary>
    /// Convert a <see cref="KernelParameterMetadata"/> to a <see cref="FunctionParameterContract"/>
    /// </summary>
    /// <param name="metadata">kernel parameter metadata</param>
    public static FunctionParameterContract ToFunctionParameterContract(this KernelParameterMetadata metadata)
    {
        return new FunctionParameterContract()
        {
            Name = metadata.Name,
            Description = metadata.Description,
            DefaultValue = metadata.DefaultValue,
            IsRequired = metadata.IsRequired,
            ParameterType = metadata.ParameterType,
        };
    }
}
