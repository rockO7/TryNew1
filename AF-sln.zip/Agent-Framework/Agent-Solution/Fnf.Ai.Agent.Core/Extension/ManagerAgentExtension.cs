﻿// <copyright file="ManagerAgentExtension.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using AutoGen.Core;

namespace Fnf.Ai.Agent.Core.Extension;

/// <summary>
/// ManagerAgentExtension class
/// </summary>
public static class ManagerAgentExtension
{
    /// <summary>
    /// Send message to an agent.
    /// </summary>
    /// <param name="agent">sender agent.</param>
    /// <param name="message">message to send. will be added to the end of <paramref name="chatHistory" /> if provided</param>
    /// <param name="chatHistory">chat history.</param>
    /// <param name="ct">The ct.</param>
    /// <returns>
    /// conversation history
    /// </returns>
    public static async Task<IMessage> SendAsync(
        this IAgent agent,
        IMessage? message = null,
        IEnumerable<IMessage>? chatHistory = null,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(agent);
        var messages = new List<IMessage>();

        if (chatHistory != null)
        {
            messages.AddRange(chatHistory);
        }

        if (message != null)
        {
            messages.Add(message);
        }

        var result = await agent.GenerateReplyAsync(messages, cancellationToken: ct)
            .ConfigureAwait(false);

        return result;
    }

    /// <summary>
    /// Send message to an agent.
    /// </summary>
    /// <param name="agent">sender agent.</param>
    /// <param name="message">message to send. will be added to the end of <paramref name="chatHistory" /> if provided</param>
    /// <param name="chatHistory">chat history.</param>
    /// <param name="ct">The ct.</param>
    /// <returns>
    /// conversation history
    /// </returns>
    public static async Task<IMessage> SendAsync(
        this IAgent agent,
        string message,
        IEnumerable<IMessage>? chatHistory = null,
        CancellationToken ct = default)
    {
        var msg = new TextMessage(Role.User, message);

        return await agent.SendAsync(msg, chatHistory, ct)
            .ConfigureAwait(false);
    }

    /// <summary>
    /// Send message to another agent and iterate over the responses.
    /// </summary>
    /// <param name="agent">sender agent.</param>
    /// <param name="receiver">receiver agent.</param>
    /// <param name="chatHistory">chat history.</param>
    /// <param name="maxRound">max conversation round.</param>
    /// <param name="ct">The ct.</param>
    /// <returns>
    /// conversation history
    /// </returns>
    public static IAsyncEnumerable<IMessage> SendAsync(
        this IAgent agent,
        IAgent receiver,
        IEnumerable<IMessage> chatHistory,
        int maxRound = 10,
        CancellationToken ct = default)
    {
        if (receiver is GroupChatManager manager)
        {
            var gc = manager.GroupChat;

            return TaskAssignmentGroupChatExtension.CallAsync(gc, chatHistory, maxRound, ct);
        }

        var groupChat = new RoundRobinGroupChat(
            agents:
            [
                agent,
                receiver,
            ]);

        return groupChat.CallAsync(chatHistory, maxRound, cancellationToken: ct);
    }

    /// <summary>
    /// Send message to another agent and iterate over the responses.
    /// </summary>
    /// <param name="agent">sender agent.</param>
    /// <param name="receiver">receiver agent.</param>
    /// <param name="message">message to send. will be added to the end of <paramref name="chatHistory" /> if provided</param>
    /// <param name="chatHistory">chat history.</param>
    /// <param name="maxRound">max conversation round.</param>
    /// <param name="ct">The ct.</param>
    /// <returns>
    /// conversation history
    /// </returns>
    public static IAsyncEnumerable<IMessage> SendAsync(
        this IAgent agent,
        IAgent receiver,
        string message,
        IEnumerable<IMessage>? chatHistory = null,
        int maxRound = 10,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(agent);
        var msg = new TextMessage(Role.User, message)
        {
            From = agent.Name,
        };

        chatHistory ??= [];
        chatHistory = chatHistory.Append(msg);

        return agent.SendAsync(receiver, chatHistory, maxRound, ct);
    }

    /// <summary>
    /// Shortcut API to send message to another agent and get all responses.
    /// To iterate over the responses,
    /// use <see cref="SendAsync(IAgent, IAgent, string, IEnumerable{IMessage}?, int, CancellationToken)" /> or <see cref="SendAsync(IAgent, IAgent, IEnumerable{IMessage}, int, CancellationToken)" />
    /// </summary>
    /// <param name="agent">sender agent</param>
    /// <param name="receiver">receiver agent</param>
    /// <param name="message">message to send</param>
    /// <param name="maxRound">max round</param>
    /// <param name="ct">The ct.</param>
    /// <returns>returns IEnumerable{IMessage}</returns>
    public static async Task<IEnumerable<IMessage>> InitiateGroupChatAsync(
        this IAgent agent,
        IAgent receiver,
        string? message = null,
        int maxRound = 10,
        CancellationToken ct = default)
    {
        ArgumentNullException.ThrowIfNull(agent);
        var chatHistory = new List<IMessage>();
        if (message != null)
        {
            var msg = new TextMessage(Role.User, message)
            {
                From = agent.Name,
            };

            chatHistory.Add(msg);
        }

        await foreach (var msg in agent.SendAsync(receiver, chatHistory, maxRound, ct).ConfigureAwait(false))
        {
            chatHistory.Add(msg);
        }

        return chatHistory;
    }
}
