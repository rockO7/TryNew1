﻿// <copyright file="SignalRMessageMiddlewareExtension.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using AutoGen.Core;
using Fnf.Ai.Agent.Core.Agent;

namespace Fnf.Ai.Agent.Core.Extension;

/// <summary>
/// SignalR Message Middleware Extension.
/// </summary>
internal static class SignalRMessageMiddlewareExtension
{
    /// <summary>
    /// Register a <see cref="IStreamingMiddleware" /> to <paramref name="agent" /> which print formatted message to console.
    /// </summary>
    /// <typeparam name="TAgent">The type of the agent.</typeparam>
    /// <param name="agent">The agent.</param>
    /// <param name="middleware">The SignalR instance</param>
    /// <returns>The MiddlewareAgent{AzureOpenAIChatAgent}</returns>
    internal static MiddlewareAgent<AzureOpenAIChatAgent> RegisterSignalRMessage<TAgent>(this AzureOpenAIChatAgent agent, IMiddleware middleware)
    {
        var middlewareAgent = new MiddlewareAgent<AzureOpenAIChatAgent>(agent);
        if (middleware != null)
        {
            middlewareAgent.Use(middleware);
        }

        return middlewareAgent;
    }

    /// <summary>
    /// Register a <see cref="IStreamingMiddleware" /> to <paramref name="agent" /> which print formatted message to console.
    /// </summary>
    /// <typeparam name="TAzureOpenAIChatAgent">The type of the azure open ai chat agent.</typeparam>
    /// <param name="agent">The agent.</param>
    /// <param name="streamingMiddleware">The SignalR instance</param>
    /// <returns>The MiddlewareStreamingAgent{AzureOpenAIChatAgent}</returns>
    internal static MiddlewareStreamingAgent<TAzureOpenAIChatAgent> RegisterSignalRMessage<TAzureOpenAIChatAgent>(
        this MiddlewareStreamingAgent<TAzureOpenAIChatAgent> agent, IStreamingMiddleware? streamingMiddleware = null)
        where TAzureOpenAIChatAgent : IStreamingAgent
    {
        var middlewareAgent = new MiddlewareStreamingAgent<TAzureOpenAIChatAgent>(agent);
        if (streamingMiddleware != null)
        {
            middlewareAgent.UseStreaming(streamingMiddleware);
        }

        return middlewareAgent;
    }
}
