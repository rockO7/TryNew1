﻿// <copyright file="AzureOpenAIAgentExtension.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using AutoGen.Core;
using Fnf.Ai.Agent.Core.Agent;
using Fnf.Ai.Agent.Core.Middleware;

namespace Fnf.Ai.Agent.Core.Extension;

/// <summary>
/// AzureOpenAIAgent Extension.
/// </summary>
internal static class AzureOpenAIAgentExtension
{
    /// <summary>
    /// Register an <see cref="AzureOpenAIChatMessageConnector"/> to the <see cref="AzureOpenAIChatAgent"/>
    /// </summary>
    /// <param name="agent">The AzureOpenAIChatAgent.</param>
    /// <param name="connector">the connector to use. If null, a new instance of <see cref="AzureOpenAIChatMessageConnector"/> will be created.</param>
    /// <returns>The MiddlewareStreamingAgent{AzureOpenAIChatAgent}</returns>
    internal static MiddlewareStreamingAgent<AzureOpenAIChatAgent> RegisterMessageConnector(
        this AzureOpenAIChatAgent agent, AzureOpenAIChatMessageConnector? connector = null)
    {
        connector ??= new AzureOpenAIChatMessageConnector();

        return agent.RegisterStreamingMiddleware(connector);
    }

    /// <summary>
    /// Register an <see cref="AzureOpenAIChatMessageConnector"/> to the <see cref="MiddlewareAgent{T}"/> where T is <see cref="AzureOpenAIChatAgent"/>
    /// </summary>
    /// <param name="agent">The AzureOpenAIChatAgent.</param>
    /// <param name="connector">the connector to use. If null, a new instance of <see cref="AzureOpenAIChatMessageConnector"/> will be created.</param>
    /// <returns>The MiddlewareStreamingAgent{AzureOpenAIChatAgent}</returns>
    internal static MiddlewareStreamingAgent<AzureOpenAIChatAgent> RegisterMessageConnector(
        this MiddlewareStreamingAgent<AzureOpenAIChatAgent> agent, AzureOpenAIChatMessageConnector? connector = null)
    {
        connector ??= new AzureOpenAIChatMessageConnector();

        return agent.RegisterStreamingMiddleware(connector);
    }
}
