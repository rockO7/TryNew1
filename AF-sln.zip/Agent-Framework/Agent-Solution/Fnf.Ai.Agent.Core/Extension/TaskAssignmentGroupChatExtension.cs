﻿// <copyright file="TaskAssignmentGroupChatExtension.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using System.Runtime.CompilerServices;
using AutoGen.Core;

namespace Fnf.Ai.Agent.Core.Extension;

/// <summary>
/// TaskAssignmentGroupChatExtension class.
/// </summary>
public static class TaskAssignmentGroupChatExtension
{
    /// <summary>
    /// The terminate
    /// </summary>
    public const string TERMINATE = "[GROUPCHAT_TERMINATE]";

    /// <summary>
    /// The clear messages
    /// </summary>
    public const string CLEAR_MESSAGES = "[GROUPCHAT_CLEAR_MESSAGES]";

    /// <summary>
    /// Send messages to a <see cref="IGroupChat" /> and return new messages from the group chat.
    /// </summary>
    /// <param name="groupChat">The group chat.</param>
    /// <param name="chatHistory">The chat history.</param>
    /// <param name="maxRound">The maximum round.</param>
    /// <param name="cancellationToken">The cancellation token.</param>
    /// <returns>IAsyncEnumerable{IMessage}</returns>
    public static async IAsyncEnumerable<IMessage> CallAsync(
        this IGroupChat groupChat,
        IEnumerable<IMessage> chatHistory,
        int maxRound = 10,
        [EnumeratorCancellation]
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(groupChat);
        ArgumentNullException.ThrowIfNull(chatHistory);
        while (maxRound-- > 0)
        {
            var messages = await groupChat.CallAsync(chatHistory, maxRound: 1, cancellationToken)
                .ConfigureAwait(false);

            // if no new messages, break the loop
            if (messages.Count() == chatHistory.Count())
            {
                yield break;
            }

            var lastMessage = messages.Last();

            yield return lastMessage;
            if (lastMessage.IsGroupChatTerminateMessage())
            {
                yield break;
            }

            // messages will contain the complete chat history, include initialize messages
            // but we only need to add the last message to the chat history
            // fix #3268
            ////chatHistory = chatHistory.Append(lastMessage);
        }
    }

    /// <summary>
    /// Send an instruction message to the group chat.
    /// </summary>
    /// <param name="agent">The agent.</param>
    /// <param name="message">The message.</param>
    /// <param name="groupChat">The group chat.</param>
    public static void SendIntroduction(this IAgent agent, string message, IGroupChat groupChat)
    {
        ArgumentNullException.ThrowIfNull(agent);
        ArgumentNullException.ThrowIfNull(groupChat);
        var msg = new TextMessage(Role.User, message)
        {
            From = agent.Name
        };

        groupChat.SendIntroduction(msg);
    }

    /// <summary>
    /// Messages to keep.
    /// </summary>
    /// <param name="groupChat">The .</param>
    /// <param name="messages">The messages.</param>
    /// <returns>IEnumerable{IMessage}</returns>
    public static IEnumerable<IMessage> MessageToKeep(
        this IGroupChat groupChat,
        IEnumerable<IMessage> messages)
    {
        var lastCLRMessageIndex = messages.ToList()
                .FindLastIndex(x => x.IsGroupChatClearMessage());

        // if multiple clr messages, e.g [msg, clr, msg, clr, msg, clr, msg]
        // only keep the the messages after the second last clr message.
        if (messages.Count(m => m.IsGroupChatClearMessage()) > 1)
        {
            lastCLRMessageIndex = messages.ToList()
                .FindLastIndex(lastCLRMessageIndex - 1, lastCLRMessageIndex - 1, x => x.IsGroupChatClearMessage());
            messages = messages.Skip(lastCLRMessageIndex);
        }

        lastCLRMessageIndex = messages.ToList()
            .FindLastIndex(x => x.IsGroupChatClearMessage());

        if (lastCLRMessageIndex != -1 && messages.Count() - lastCLRMessageIndex >= 2)
        {
            messages = messages.Skip(lastCLRMessageIndex);
        }

        return messages;
    }

    /// <summary>
    /// Return true if <see cref="IMessage" /> contains <see cref="TERMINATE" />, otherwise false.
    /// </summary>
    /// <param name="message">The message.</param>
    /// <returns>
    ///   <c>true</c> if [is group chat terminate message] [the specified message]; otherwise, <c>false</c>.
    /// </returns>
    public static bool IsGroupChatTerminateMessage(this IMessage message)
    {
        return message.GetContent()?.Contains(TERMINATE, StringComparison.InvariantCultureIgnoreCase) ?? false;
    }

    /// <summary>
    /// Determines whether [is group chat clear message].
    /// </summary>
    /// <param name="message">The message.</param>
    /// <returns>
    ///   <c>true</c> if [is group chat clear message] [the specified message]; otherwise, <c>false</c>.
    /// </returns>
    public static bool IsGroupChatClearMessage(this IMessage message)
    {
        return message.GetContent()?.Contains(CLEAR_MESSAGES, StringComparison.InvariantCultureIgnoreCase) ?? false;
    }

    /// <summary>
    /// Processes the conversations for role play.
    /// </summary>
    /// <param name="groupChat">The group chat.</param>
    /// <param name="initialMessages">The initial messages.</param>
    /// <param name="messages">The messages.</param>
    /// <returns>IEnumerable{IMessage}</returns>
    internal static IEnumerable<IMessage> ProcessConversationsForRolePlay(
            this IGroupChat groupChat,
            IEnumerable<IMessage> initialMessages,
            IEnumerable<IMessage> messages)
    {
        messages = groupChat.MessageToKeep(messages);
        var messagesToKeep = initialMessages.Concat(messages);

        return messagesToKeep.Select((x, i) =>
        {
            var msg = @$"From {x.From}:
                    {x.GetContent()}
                    <eof_msg>
                    round # {i}";

            return new TextMessage(Role.User, content: msg);
        });
    }
}
