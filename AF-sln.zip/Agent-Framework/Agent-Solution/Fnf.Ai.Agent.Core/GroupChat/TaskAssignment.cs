﻿// <copyright file="TaskAssignment.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using AutoGen.Core;
using Fnf.Ai.Agent.Core.Orchestrator;

namespace Fnf.Ai.Agent.Core.GroupChat;

/// <summary>
/// Task Dispatcher.
/// </summary>
/// <seealso cref="AutoGen.Core.IGroupChat" />
public class TaskAssignment : IGroupChat
{
    private readonly List<IAgent> _agents;
    private readonly Graph? _workflow;
    private readonly IOrchestrator _orchestrator;
    private IEnumerable<IMessage> _initializeMessages = [];

    /// <summary>
    /// Initializes a new instance of the <see cref="TaskAssignment"/> class.
    /// Create a group chat. The next speaker will be decided by a combination effort of the admin and the workflow.
    /// </summary>
    /// <param name="members">group members.</param>
    /// <param name="admin">admin agent. If provided, the admin will be invoked to decide the next speaker.</param>
    /// <param name="initializeMessages">The chat history or initial messages between agents and user.</param>
    /// <param name="workflow">workflow of the group chat. If provided, the next speaker will be decided by the workflow.</param>
    public TaskAssignment(
        IEnumerable<IAgent> members,
        IAgent? admin = null,
        IEnumerable<IMessage>? initializeMessages = null,
        Graph? workflow = null)
    {
        ArgumentNullException.ThrowIfNull(members);
        this._agents = members.ToList();
        ArgumentOutOfRangeException.ThrowIfZero(this._agents.Count);

        this._initializeMessages = initializeMessages ?? [];
        this._workflow = workflow;

        if (admin is not null)
        {
            this._orchestrator = new TaskAssignmentOrchestrator(admin, workflow);
        }
        else
        {
            this._orchestrator = workflow is not null ? new WorkflowOrchestrator(workflow) : new RoundRobinOrchestrator();
        }

        this.Validation();
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="TaskAssignment"/> class.
    /// Create a group chat which uses the <paramref name="orchestrator"/> to decide the next speaker(s).
    /// </summary>
    /// <param name="members">The group members.</param>
    /// <param name="orchestrator">The task assignment orchestrator.</param>
    /// <param name="initializeMessages">The chat history or initial messages between agents and user.</param>
    public TaskAssignment(
        IEnumerable<IAgent> members,
        IOrchestrator orchestrator,
        IEnumerable<IMessage>? initializeMessages = null)
    {
        this._agents = members.ToList();
        this._initializeMessages = initializeMessages ?? [];
        this._orchestrator = orchestrator;

        this.Validation();
    }

    /// <summary>
    /// Gets the messages.
    /// </summary>
    /// <value>
    /// The messages.
    /// </value>
    public IEnumerable<IMessage>? Messages { get; }

    /// <inheritdoc />
    public void AddInitializeMessage(IMessage message)
    {
        this.SendIntroduction(message);
    }

    /// <summary>
    /// Calls the asynchronous.
    /// </summary>
    /// <param name="conversation">The chat history.</param>
    /// <param name="maxRound">The maximum round.</param>
    /// <param name="ct">The ct.</param>
    /// <returns>The List of IMessage</returns>
    public async Task<IEnumerable<IMessage>> CallAsync(
    IEnumerable<IMessage>? conversation = null,
    int maxRound = 10,
    CancellationToken ct = default)
    {
        var conversationHistory = new List<IMessage>();
        conversationHistory.AddRange(this._initializeMessages);
        if (conversation != null)
        {
            //var currentConversation = conversation.Count() > 1 ? conversation.SkipLast(1) : conversation;
            //conversationHistory.AddRange(currentConversation);
            conversationHistory.AddRange(conversation);
        }

        var roundLeft = maxRound;
        var terminate = false;

        while (roundLeft > 0 && !terminate)
        {
            var orchestratorContext = new OrchestrationContext
            {
                Candidates = this._agents,
                ChatHistory = conversationHistory,
            };
            var nextSpeaker = await this._orchestrator.GetNextSpeakerAsync(orchestratorContext, ct)
                .ConfigureAwait(false);
            if (nextSpeaker == null)
            {
                terminate = true;
                continue;
            }

            var result = await nextSpeaker.GenerateReplyAsync(conversationHistory, cancellationToken: ct)
                .ConfigureAwait(false);
            if (IsTerminateAgentProcess(result))
            {
                conversationHistory.Add(new TextMessage(result.GetRole()!.Value, $"{result.GetContent()} and [GROUPCHAT_TERMINATE]", result.From));
                return conversationHistory;
            }

            if (result.From == "Greetings")
            {
                conversationHistory.Add(new TextMessage(result.GetRole()!.Value, "[TERMINATE] and [GROUPCHAT_TERMINATE]", result.From));
                return conversationHistory;
            }

            conversationHistory.Add(result);
            if (result.IsGroupChatTerminateMessage())
            {
                return conversationHistory;
            }

            roundLeft--;
        }

        return conversationHistory;
    }

    /// <summary>
    /// Send an introduction message to the group chat.
    /// </summary>
    /// <param name="message">The IMessage.</param>
    public void SendIntroduction(IMessage message)
    {
        this._initializeMessages = this._initializeMessages.Append(message);
    }

    private static bool IsTerminateAgentProcess(IMessage replyFromAgent)
    {
        return !string.IsNullOrWhiteSpace(replyFromAgent?.GetContent())
            && replyFromAgent.GetContent()!.Contains("TERMINATE", StringComparison.InvariantCulture);
    }

    private void Validation()
    {
        // check if all agents has a name
        if (this._agents.Exists(x => string.IsNullOrEmpty(x.Name)))
        {
            throw new AgentException("All agents must have a name.");
        }

        // check if any agents has the same name
        var names = this._agents.Select(x => x.Name).ToList();
        if (names.Distinct().Count() != names.Count)
        {
            throw new AgentException("All agents must have a unique name.");
        }

        // if there's a workflow
        // check if the agents in that workflow are in the group chat
        if (this._workflow != null)
        {
            var agentNamesInWorkflow = this._workflow.Transitions.Select(x => x.From.Name!).Concat(this._workflow.Transitions.Select(x => x.To.Name!)).Distinct();
            if (agentNamesInWorkflow.Any(x => !this._agents.Select(a => a.Name).Contains(x)))
            {
                throw new AgentException("All agents in the workflow must be in the group chat.");
            }
        }
    }
}
