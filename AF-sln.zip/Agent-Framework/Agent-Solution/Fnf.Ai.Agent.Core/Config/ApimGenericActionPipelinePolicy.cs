﻿// <copyright file="ApimGenericActionPipelinePolicy.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using System.ClientModel.Primitives;

namespace Fnf.Ai.Agent.Core.Config;

/// <summary>
/// ApimGenericActionPipelinePolicy
/// </summary>
/// <seealso cref="System.ClientModel.Primitives.PipelinePolicy" />
internal class ApimGenericActionPipelinePolicy : PipelinePolicy
{
    private readonly Action<PipelineRequest> _requestAction;
    private readonly Action<PipelineResponse> _responseAction;

    /// <summary>
    /// Initializes a new instance of the <see cref="ApimGenericActionPipelinePolicy"/> class.
    /// </summary>
    /// <param name="requestAction">The request action.</param>
    /// <param name="responseAction">The response action.</param>
    public ApimGenericActionPipelinePolicy(Action<PipelineRequest> requestAction = null, Action<PipelineResponse> responseAction = null)
    {
        this._requestAction = requestAction;
        this._responseAction = responseAction;
    }

    /// <summary>
    /// Process the provided <see cref="System.ClientModel.Primitives.PipelineMessage" /> according to the
    /// intended purpose of this <see cref="System.ClientModel.Primitives.PipelinePolicy" />instance.
    /// Derived types must pass control to the next
    /// <see cref="System.ClientModel.Primitives.PipelinePolicy" /> in the pipeline by calling
    /// <see cref="System.ClientModel.Primitives.PipelinePolicy.ProcessNext(
    /// System.ClientModel.Primitives.PipelineMessage,System.Collections.Generic.IReadOnlyList{System.ClientModel.Primitives.PipelinePolicy},int)" />.
    /// </summary>
    /// <param name="message">The <see cref="System.ClientModel.Primitives.PipelineMessage" /> to process.</param>
    /// <param name="pipeline">The collection of <see cref="System.ClientModel.Primitives.PipelinePolicy" />
    /// instances in the <see cref="System.ClientModel.Primitives.ClientPipeline" /> instance whose
    /// <see cref="System.ClientModel.Primitives.ClientPipeline.Send(System.ClientModel.Primitives.PipelineMessage)" /> method was called to invoke
    /// this method.</param>
    /// <param name="currentIndex">The index of this policy in the
    /// <paramref name="pipeline" /> policy list. This value should be passed to
    /// <see cref="System.ClientModel.Primitives.PipelinePolicy.ProcessNext(
    /// System.ClientModel.Primitives.PipelineMessage,System.Collections.Generic.IReadOnlyList{System.ClientModel.Primitives.PipelinePolicy},int)" />
    /// to pass control to the next policy in the pipeline.</param>
    public override void Process(PipelineMessage message, IReadOnlyList<PipelinePolicy> pipeline, int currentIndex)
    {
        this._requestAction?.Invoke(message.Request);
        ProcessNext(message, pipeline, currentIndex);
        this._responseAction?.Invoke(message.Response);
    }

    /// <summary>
    /// Process the provided <see cref="System.ClientModel.Primitives.PipelineMessage" /> according to the
    /// intended purpose of this <see cref="System.ClientModel.Primitives.PipelinePolicy" />instance.
    /// Derived types must pass control to the next
    /// <see cref="System.ClientModel.Primitives.PipelinePolicy" /> in the pipeline by calling
    /// <see cref="System.ClientModel.Primitives.PipelinePolicy.ProcessNextAsync(
    /// System.ClientModel.Primitives.PipelineMessage,System.Collections.Generic.IReadOnlyList{System.ClientModel.Primitives.PipelinePolicy},int)" />.
    /// </summary>
    /// <param name="message">The <see cref="System.ClientModel.Primitives.PipelineMessage" /> to process.</param>
    /// <param name="pipeline">The collection of <see cref="System.ClientModel.Primitives.PipelinePolicy" />
    /// instances in the <see cref="System.ClientModel.Primitives.ClientPipeline" /> instance whose
    /// <see cref="System.ClientModel.Primitives.ClientPipeline.SendAsync(System.ClientModel.Primitives.PipelineMessage)" /> method was called to invoke
    /// this method.</param>
    /// <param name="currentIndex">The index of this policy in the
    /// <paramref name="pipeline" /> policy list. This value should be passed to
    /// <see cref="System.ClientModel.Primitives.PipelinePolicy.ProcessNextAsync(
    /// System.ClientModel.Primitives.PipelineMessage,System.Collections.Generic.IReadOnlyList{System.ClientModel.Primitives.PipelinePolicy},int)" />
    /// to pass control to the next policy in the pipeline.</param>
    /// <returns>The Value Task.</returns>
    public override async ValueTask ProcessAsync(PipelineMessage message, IReadOnlyList<PipelinePolicy> pipeline, int currentIndex)
    {
        this._requestAction?.Invoke(message.Request);
        await ProcessNextAsync(message, pipeline, currentIndex).ConfigureAwait(false);
        this._responseAction?.Invoke(message.Response);
    }
}
