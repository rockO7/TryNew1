﻿// <copyright file="AzureOpenAIConfig.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using System.ClientModel;
using AutoGen.Core;
using Azure;
using Azure.AI.OpenAI;
////using Azure.Identity;
using OpenAI.Chat;

namespace Fnf.Ai.Agent.Core.Config;

/// <summary>
/// LLM config.
/// </summary>
/// <seealso cref="AutoGen.Core.ILLMConfig" />
public class AzureOpenAIConfig : ILLMConfig
{
    /// <summary>
    /// Initializes a new instance of the <see cref="AzureOpenAIConfig"/> class.
    /// </summary>
    /// <param name="endpoint">The endpoint.</param>
    /// <param name="deploymentName">Name of the deployment.</param>
    /// <param name="temperature">The temperature.</param>
    /// <param name="maxTokens">The maximum tokens.</param>
    /// <param name="seed">The seed.</param>
    public AzureOpenAIConfig(string endpoint, string deploymentName, float temperature = 0.7f, int maxTokens = 1024, int? seed = null)
    {
        this.Endpoint = endpoint;
        this.DeploymentName = deploymentName;
        this.Temperature = temperature;
        this.MaxTokens = maxTokens;
        this.Seed = seed;
    }

    /// <summary>
    /// Gets the endpoint.
    /// </summary>
    /// <value>
    /// The endpoint.
    /// </value>
    public string Endpoint { get; }

    /// <summary>
    /// Gets the name of the deployment.
    /// </summary>
    /// <value>
    /// The name of the deployment.
    /// </value>
    public string DeploymentName { get; }

    /// <summary>
    /// Gets the temperature.
    /// </summary>
    /// <value>
    /// The temperature.
    /// </value>
    public float Temperature { get; }

    /// <summary>
    /// Gets the maximum tokens.
    /// </summary>
    /// <value>
    /// The maximum tokens.
    /// </value>
    public int MaxTokens { get; }

    /// <summary>
    /// Gets the seed.
    /// </summary>
    /// <value>
    /// The seed.
    /// </value>
    public int? Seed { get; }

    /// <summary>
    /// Creates the chat client.
    /// </summary>
    /// <returns>The ChatClient.</returns>
    public ChatClient CreateChatClient()
    {
        var openAIClient = new AzureOpenAIClient(new Uri("https://oai-access-1.openai.azure.com/"), new AzureKeyCredential("4953ce135f334138a4ece0a0c03ecfcb"));

        ////var openAIClient = new AzureOpenAiClientWithApim(
        ////    new Uri($"https://fnf-geai-apim-d1-use2-01.azure-api.net/openai/deployments/{this.DeploymentName}"),
        ////    new ApiKeyCredential("4ec4a28623ed49958e81fc62a3b99999;product=genie"),
        ////    new AzureOpenAIClientOptions(AzureOpenAIClientOptions.ServiceVersion.V2024_10_01_Preview));

        return openAIClient.GetChatClient("chatgpt-4o-mini");
    }
}
