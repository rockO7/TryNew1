﻿// <copyright file="AzureApimChatClient.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using System.ClientModel;
using System.ClientModel.Primitives;
using Azure.AI.OpenAI;
using OpenAI;
using OpenAI.Chat;

namespace Fnf.Ai.Agent.Core.Config;

/// <summary>
/// Azure Apim Chat Client
/// </summary>
/// <seealso cref="OpenAI.Chat.ChatClient" />
internal class AzureApimChatClient : ChatClient
{
    private readonly string _deploymentName;
    private readonly Uri _endpoint;
    ////private readonly string _apiVersion;

    /// <summary>
    /// Initializes a new instance of the <see cref="AzureApimChatClient"/> class.
    /// </summary>
    /// <param name="pipeline">The pipeline.</param>
    /// <param name="deploymentName">Name of the deployment.</param>
    /// <param name="endpoint">The endpoint.</param>
    /// <param name="options">The options.</param>
    internal AzureApimChatClient(ClientPipeline pipeline, string deploymentName, Uri endpoint, AzureOpenAIClientOptions options)
        : base(pipeline, model: deploymentName, new OpenAIClientOptions() { Endpoint = endpoint })
    {
        ArgumentNullException.ThrowIfNull(pipeline, nameof(pipeline));
        ArgumentException.ThrowIfNullOrWhiteSpace(deploymentName, nameof(deploymentName));
        ArgumentNullException.ThrowIfNull(endpoint, nameof(endpoint));
        _ = options ?? new();

        this._deploymentName = deploymentName;
        this._endpoint = endpoint;
        ////this._apiVersion = options.Version;
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="AzureApimChatClient"/> class.
    /// </summary>
    protected AzureApimChatClient()
    {
    }

    /// <inheritdoc/>
    public override AsyncCollectionResult<StreamingChatCompletionUpdate> CompleteChatStreamingAsync(
        IEnumerable<ChatMessage> messages, ChatCompletionOptions options = null, CancellationToken cancellationToken = default)
    {
        options ??= new();
        ////options.StreamOptions = null;
        return base.CompleteChatStreamingAsync(messages, options, cancellationToken);
    }

    /// <inheritdoc/>
    public override CollectionResult<StreamingChatCompletionUpdate> CompleteChatStreaming(
        IEnumerable<ChatMessage> messages, ChatCompletionOptions options = null, CancellationToken cancellationToken = default)
    {
        options ??= new();
        ////options.StreamOptions = null;
        return base.CompleteChatStreaming(messages, options, cancellationToken);
    }
}
