﻿// <copyright file="AzureOpenAiClientWithApim.cs" company="FNF">
// Copyright (c) FNF. All rights reserved.
// </copyright>.

using System.ClientModel;
using System.ClientModel.Primitives;
using Azure;
using Azure.AI.OpenAI;
using OpenAI;
using OpenAI.Chat;

namespace Fnf.Ai.Agent.Core.Config;

/// <summary>
/// AzureOpenAiClientWithApim.
/// </summary>
/// <seealso cref="OpenAI.OpenAIClient" />
public class AzureOpenAiClientWithApim : OpenAIClient
{
    private const string UserAgentHeaderKey = "User-Agent";
    private const string ClientRequestIdHeaderKey = "x-ms-client-request-id";
    private static PipelineMessageClassifier? s_pipelineMessageClassifier;
    private readonly Uri _endpoint;
    private readonly AzureOpenAIClientOptions _options;

    /// <summary>
    /// Initializes a new instance of the <see cref="AzureOpenAiClientWithApim"/> class.
    /// </summary>
    /// <remarks>
    /// <para>
    /// For token-based authentication, including the use of managed identity, please use the alternate constructor:
    /// </para>
    /// </remarks>
    /// <param name="endpoint"> The Azure OpenAI resource endpoint to use.
    /// This should not include model deployment or operation information. For example: <c>https://my-resource.openai.azure.com</c>. </param>
    /// <param name="credential"> The API key to authenticate with the service. </param>
    public AzureOpenAiClientWithApim(Uri endpoint, ApiKeyCredential credential)
        : this(endpoint, credential, new AzureOpenAIClientOptions())
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="AzureOpenAiClientWithApim"/> class.
    /// </summary>
    /// <param name="endpoint">The endpoint.</param>
    /// <param name="credential">The credential.</param>
    /// <param name="options">The options.</param>
    public AzureOpenAiClientWithApim(Uri endpoint, ApiKeyCredential credential, AzureOpenAIClientOptions options)
        : this(CreatePipeline(credential, options), endpoint, options)
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="AzureOpenAiClientWithApim"/> class.
    /// </summary>
    /// <param name="pipeline">The pipeline.</param>
    /// <param name="endpoint">The endpoint.</param>
    /// <param name="options">The options.</param>
    protected AzureOpenAiClientWithApim(ClientPipeline pipeline, Uri endpoint, AzureOpenAIClientOptions options)
        : base(pipeline, new OpenAIClientOptions { Endpoint = endpoint })
    {
        options ??= new();

        this._endpoint = endpoint;
        this._options = options;
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="AzureOpenAiClientWithApim"/> class.
    /// </summary>
    protected AzureOpenAiClientWithApim()
    {
    }

    /// <summary>
    /// Gets the pipeline message classifier.
    /// </summary>
    /// <value>
    /// The pipeline message classifier.
    /// </value>
    internal static PipelineMessageClassifier PipelineMessageClassifier
        => s_pipelineMessageClassifier ??= PipelineMessageClassifier.Create(stackalloc ushort[] { 200, 201 });

    /// <summary>
    /// Gets a new <see cref="ChatClient"/> instance configured for chat completion operation use with the Azure OpenAI service.
    /// </summary>
    /// <param name="model"> The model deployment name to use for the new client's chat completion operations. </param>
    /// <returns> A new <see cref="ChatClient"/> instance. </returns>
    public override ChatClient GetChatClient(string model)
        => new AzureApimChatClient(this.Pipeline, model, this._endpoint, this._options);

    /// <summary>
    /// Creates the pipeline.
    /// </summary>
    /// <param name="credential">The credential.</param>
    /// <param name="options">The options.</param>
    /// <returns>The ClientPipeline.</returns>
    /// <exception cref="System.ArgumentNullException">credential</exception>
    internal static ClientPipeline CreatePipeline(ApiKeyCredential credential, AzureOpenAIClientOptions options = null)
    {
        ArgumentNullException.ThrowIfNull(credential, nameof(credential));
        return CreatePipeline(ApiKeyAuthenticationPolicy.CreateHeaderApiKeyPolicy(credential, "Ocp-Apim-Subscription-Key"), options);
    }

    private static ClientPipeline CreatePipeline(PipelinePolicy authenticationPolicy, AzureOpenAIClientOptions options)
        => ClientPipeline.Create(
            options ?? new(),
            perCallPolicies:
            [
                CreateAddUserAgentHeaderPolicy(options),
                CreateAddClientRequestIdHeaderPolicy(),
            ],
            perTryPolicies:
            [
                authenticationPolicy,
            ],
            beforeTransportPolicies: []);

    private static PipelinePolicy CreateAddUserAgentHeaderPolicy(AzureOpenAIClientOptions options = null)
    {
        Azure.Core.TelemetryDetails telemetryDetails = new(typeof(AzureOpenAiClientWithApim).Assembly, options?.UserAgentApplicationId);
        return new ApimGenericActionPipelinePolicy(
            requestAction: request =>
            {
                if (request?.Headers?.TryGetValue(UserAgentHeaderKey, out string _) == false)
                {
                    request.Headers.Set(UserAgentHeaderKey, telemetryDetails.ToString());
                }
            });
    }

    private static PipelinePolicy CreateAddClientRequestIdHeaderPolicy()
    {
        return new ApimGenericActionPipelinePolicy(request =>
        {
            if (request?.Headers is not null)
            {
                var requestId = request.Headers.TryGetValue(ClientRequestIdHeaderKey, out string existingHeader)
                ? existingHeader
                    : Guid.NewGuid().ToString().ToLowerInvariant();
                request.Headers.Set(ClientRequestIdHeaderKey, requestId);
                request.Uri = new Uri($"{request.Uri.OriginalString}?api-version=2024-07-01-preview");
            }
        });
    }
}
